package main;
import java.util.*;
public class Camino {
    public static int CaminomasCorto(Grafo grafo, int sourceIndex, int destIndex, List<Dispositivos> path) {
        int tamaño = grafo.obtenerDispositivos().size();
        int[] dist = new int[tamaño];
        boolean[] visited = new boolean[tamaño];
        int[] prev = new int[tamaño];
        Arrays.fill(dist, Integer.MAX_VALUE);
        Arrays.fill(prev, -1);
        dist[sourceIndex] = 0;
        for (int i = 0; i < tamaño; i++) {
            int current = -1;
            for (int j = 0; j < tamaño; j++) {
                if (!visited[j] && (current == -1 || dist[j] < dist[current])) {
                    current = j;
                }
            }
            if (dist[current] == Integer.MAX_VALUE) {
                break;
            }
            visited[current] = true;
            for (int j = 0; j < tamaño; j++) {
                int weight = grafo.ObtenerMatrizA()[current][j];
                if (weight > 0 && dist[current] + weight < dist[j]) {
                    dist[j] = dist[current] + weight;
                    prev[j] = current;
                }
            }
        }
        if (dist[destIndex] == Integer.MAX_VALUE) {
            return -1; // No hay ruta
        }
        // Reconstruir el camino
        for (int at = destIndex; at != -1; at = prev[at]) {
            path.add(0, grafo.obtenerDispositivo(at));
        }
        return dist[destIndex];
    }
}
