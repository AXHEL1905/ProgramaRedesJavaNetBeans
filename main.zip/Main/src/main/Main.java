package main;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        // Crear el grafo
        Grafo grafo = new Grafo(10);
        // Agregar dispositivos
        grafo.agregarDispositivis(new PC("PC0"));
        grafo.agregarDispositivis(new PC("PC1"));
        grafo.agregarDispositivis(new Impresora("Impresora"));
        grafo.agregarDispositivis(new Switch("Switch"));
        grafo.agregarDispositivis(new Router("Router"));
        grafo.agregarDispositivis(new Laptop("Laptop"));
        grafo.agregarDispositivis(new Celular("Celular"));
        grafo.agregarDispositivis(new Laptop("Tablet"));
        grafo.agregarDispositivis(new PC("Servidor"));
        grafo.agregarDispositivis(new PC("Cámara"));
        // Definir conexiones
        grafo.agrgarConexiones(0, 1, 5);
        grafo.agrgarConexiones(1, 2, 10);
        grafo.agrgarConexiones(2, 3, 15);
        grafo.agrgarConexiones(3, 4, 20);
        grafo.agrgarConexiones(4, 5, 25);
        grafo.agrgarConexiones(5, 6, 30);
        grafo.agrgarConexiones(6, 7, 35);
        grafo.agrgarConexiones(7, 8, 40);
        grafo.agrgarConexiones(8, 9, 45);
        grafo.agrgarConexiones(9, 0, 50);
        // Imprimir matriz de adyacencia
        grafo.imprimirMatriz();
        // Simular envíos de paquetes (3 simulaciones)
        for (int i = 0; i < 3; i++) {
            Dispositivos origen = DispositivoRandom(grafo.obtenerDispositivos());
            Dispositivos destino = DispositivoRandom(grafo.obtenerDispositivos());
            while (destino.equals(origen)) {
                destino = DispositivoRandom(grafo.obtenerDispositivos());
            }
            SimulacionEnvio.SimulaciondeEnvio(grafo, origen, destino);
        }
    }
    private static Dispositivos DispositivoRandom(List<Dispositivos> Dispositivos) {
        return Dispositivos.get(new Random().nextInt(Dispositivos.size()));
    }
}
