package main;

public class Dispositivos {
  // Clase base para representar un dispositivo
    String name;
    public Dispositivos(String name) {
        this.name = name;
    }
    @Override
    public String toString() {
        return name;
    }
}
// Clases derivadas
class PC extends Dispositivos {
    public PC(String name) {
        super(name);
    }
}

class Router extends Dispositivos {
    public Router(String name) {
        super(name);
    }
}

class Switch extends Dispositivos {
    public Switch(String name) {
        super(name);
    }
}

class Laptop extends Dispositivos {
    public Laptop(String name) {
        super(name);
    }
}

class Celular extends Dispositivos {
    public Celular(String name) {
        super(name);
    }
}

class Impresora extends Dispositivos {
    public Impresora(String name) {
        super(name);
    }
}
