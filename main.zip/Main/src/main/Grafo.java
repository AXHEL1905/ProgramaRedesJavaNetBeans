package main;
import java.util.*;
public class Grafo {
    public int[][] MatrizA;
    public List<Dispositivos> Dispositivos;

    public Grafo(int tamaño) {
        this.MatrizA = new int[tamaño][tamaño];
        this.Dispositivos = new ArrayList<>();
    }
    // Agregar un dispositivo al grafo
    public void agregarDispositivis(Dispositivos device) {
        Dispositivos.add(device);
    }
    // Agregar una conexión entre dos dispositivos
    public void agrgarConexiones(int sourceIndex, int destIndex, int weight) {
        MatrizA[sourceIndex][destIndex] = weight;
        MatrizA[destIndex][sourceIndex] = weight; // Conexión bidireccional
    }
    // Obtener la matriz de adyacencia
    public int[][] ObtenerMatrizA() {
        return MatrizA;
    }
    // Obtener un dispositivo por índice
    public Dispositivos obtenerDispositivo(int index) {
        return Dispositivos.get(index);
    }
    // Obtener todos los dispositivos
    public List<Dispositivos> obtenerDispositivos() {
        return Dispositivos;
    }
    // Imprimir la matriz de adyacencia
    public void imprimirMatriz() {
        System.out.print("     ");
        for (Dispositivos device : Dispositivos) {
            System.out.print(device.name + "\t");
        }
        System.out.println();

        for (int i = 0; i < MatrizA.length; i++) {
            System.out.print(Dispositivos.get(i).name + "  ");
            for (int j = 0; j < MatrizA[i].length; j++) {
                System.out.print(MatrizA[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
