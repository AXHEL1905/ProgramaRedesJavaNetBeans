package main;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
public class SimulacionEnvio {
    public static void SimulaciondeEnvio(Grafo grafo, Dispositivos origen, Dispositivos destino) {
        List<Dispositivos> camino = new ArrayList<>();
        int Tiempototal = Camino.CaminomasCorto(grafo, grafo.obtenerDispositivos().indexOf(origen), grafo.obtenerDispositivos().indexOf(destino), camino);
        if (Tiempototal == -1) {
            System.out.println("No hay ruta disponible entre " + origen + " y " + destino);
            return;
        }
        // Calcular la hora de envío y llegada
        LocalTime envio = LocalTime.now();
        LocalTime llegada = envio.plusSeconds(Tiempototal);
        // Mostrar resultado
        System.out.println("\nResultado del Envío:");
        System.out.println("  Origen: " + origen);
        System.out.println("  Destino: " + destino);
        System.out.println("  Ruta: " + camino);
        System.out.println("  Hora de envío: " + envio.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        System.out.println("  Hora de llegada: " + llegada.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        System.out.println("  Tiempo total: " + Tiempototal + " segundos\n");
    }
}
